package com.example.demoproproyectofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoproproyectofinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
