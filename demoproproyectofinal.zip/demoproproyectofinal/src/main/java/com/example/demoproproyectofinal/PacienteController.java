package com.example.demoproproyectofinal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;

    @PostMapping("/registrar")
    public Paciente registrarPaciente(@RequestBody Paciente paciente) {
        // Aquí deberías llamar al servicio para registrar al paciente
        // y devolver el paciente registrado
        return pacienteService.registrarPaciente(paciente);
    }

    // Otros métodos del controlador según las necesidades de tu aplicación
}
