package com.example.demoproproyectofinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoproproyectofinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoproproyectofinalApplication.class, args);
	}

}
