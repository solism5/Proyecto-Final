package com.example.demoproproyectofinal.repository;

public interface JpaRepository<T1, T2> {

}
