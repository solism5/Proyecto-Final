package com.example.demoproproyectofinal.repository;

import com.example.demoproproyectofinal.Paciente;

import java.util.List;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {

    List<Paciente> findByNombre(String nombre);

    List<Paciente> findByApellido(String apellido);

    Paciente findByEmail(String email);
}
