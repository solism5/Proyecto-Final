package com.example.demoproproyectofinal.Model;

public class GenerationType {

}
