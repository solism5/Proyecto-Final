package com.example.demoproproyectofinal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demoproproyectofinal.Model.Usuario;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private Usuario usuarioService;

    @PostMapping("/crear")
    public <usuarioService, usuarioService> Usuario crearUsuario(@RequestBody Usuario usuario) {
        // Aquí deberías llamar al servicio para crear al usuario
        // y devolver el usuario creado
        return usuarioService.crearUsuario(usuario);
    }

    // Otros métodos del controlador según las necesidades de tu aplicación
}