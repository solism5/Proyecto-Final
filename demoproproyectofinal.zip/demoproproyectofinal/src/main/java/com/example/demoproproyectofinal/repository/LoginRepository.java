package com.example.demoproproyectofinal.repository;

import com.example.demoproproyectofinal.Model.Login;

public interface LoginRepository extends JpaRepository<Login, Long> {

    Login findByNombreUsuario(String nombreUsuario);

    Login findByNombreUsuarioAndContraseña(String nombreUsuario, String contraseña);
}