package com.example.demoproproyectofinal.repository;

public class Usuario {

}
