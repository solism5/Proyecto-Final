package com.example.demoproproyectofinal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demoproproyectofinal.Model.Login;

@RestController
@RequestMapping("/api/login")
public class LoginController<LoginService> {

    @Autowired
    private LoginService loginService;

    @PostMapping("/autenticar")
    public String autenticar(@RequestBody Login login) {
        // Aquí deberías llamar al servicio para autenticar el login
        // y devolver una respuesta adecuada
        return ((Object) loginService).autenticar(login);
    }

    // Otros métodos del controlador según las necesidades de tu aplicación
}