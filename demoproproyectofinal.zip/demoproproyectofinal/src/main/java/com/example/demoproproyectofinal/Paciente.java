package com.example.demoproproyectofinal;

public class Paciente {

}
